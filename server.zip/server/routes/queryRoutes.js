const express = require('express');
const { spawnSync } = require('child_process');
const path = require('path');

const router = express.Router();

router.post('/', (req, res) => {
  const { question, context } = req.body;

  const result = spawnSync('python', [
    path.join(__dirname, '../query_handler.py'),
    question,
    context
  ], {
    encoding: 'utf-8'
  });

  const output = result.stdout.trim();
  console.log('QA OUTPUT:', output);

  if (!output || output.startsWith("Error:")) {
    res.status(500).json({ error: 'Answer not available.' });
  } else {
    res.json({ answer: output });
  }
});

module.exports = router;