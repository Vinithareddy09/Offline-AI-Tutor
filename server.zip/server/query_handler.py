from transformers import pipeline
import sys

def main():
    try:
        question = sys.argv[1]
        context = sys.argv[2]
        qa = pipeline(
            "question-answering",
            model="./models/distilbert-base-uncased-distilled-squad",
            tokenizer="./models/distilbert-base-uncased-distilled-squad"
        )
        result = qa(question=question, context=context)
        print(result['answer'])
    except Exception as e:
        print("Error:", str(e))

if __name__ == '__main__':
    main()
