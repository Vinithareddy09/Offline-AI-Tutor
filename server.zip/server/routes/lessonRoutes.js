const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const lessonsPath = path.join(__dirname, '../../assets/lessons');

router.get('/', (req, res) => {
  const files = fs.readdirSync(lessonsPath);
  const subjects = files.map(f => f.replace('.json', ''));
  res.json(subjects);
});

router.get('/:subject', (req, res) => {
  const subject = req.params.subject;
  const filePath = path.join(lessonsPath, `${subject}.json`);
  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, 'utf-8');
    res.json(JSON.parse(data));
  } else {
    res.status(404).json({ error: 'Lesson not found' });
  }
});

module.exports = router;