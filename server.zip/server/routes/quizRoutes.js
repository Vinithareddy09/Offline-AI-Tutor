const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const quizzesPath = path.join(__dirname, '../../assets/quizzes');

router.get('/:subject', (req, res) => {
  const file = path.join(quizzesPath, `${req.params.subject}.json`);
  if (fs.existsSync(file)) {
    const data = fs.readFileSync(file, 'utf8');
    res.json(JSON.parse(data));
  } else {
    res.status(404).json({ error: 'Quiz not found' });
  }
});

module.exports = router;