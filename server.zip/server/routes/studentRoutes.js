const express = require('express');
const fs = require('fs');
const router = express.Router();
const path = require('path');
const filePath = path.join(__dirname, '../../assets/student_data.json');


function readData() {
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

function writeData(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

router.post('/login', (req, res) => {
  const { name } = req.body;
  let data = readData();

  if (!data[name]) {
    data[name] = { lessonsRead: [], quizzes: [] };
    writeData(data);
  }

  res.json({
    name,
    history: data[name].quizzes,
    lessonsRead: data[name].lessonsRead,
  });
});

router.post('/:name/progress', (req, res) => {
  const { name } = req.params;
  const { subject, score } = req.body;

  let data = readData();
  if (!data[name]) return res.status(404).json({ error: 'User not found' });

  const quizEntry = { subject, score, date: new Date().toISOString() };
  data[name].quizzes.push(quizEntry);

  if (!data[name].lessonsRead.includes(subject)) {
    data[name].lessonsRead.push(subject);
  }

  writeData(data);

  res.json({
    message: 'Progress updated',
    user: {
      name,
      history: data[name].quizzes,
      lessonsRead: data[name].lessonsRead,
    }
  });
});

module.exports = router;